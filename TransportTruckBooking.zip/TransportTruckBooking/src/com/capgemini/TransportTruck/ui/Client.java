package com.capgemini.TransportTruck.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.TransportTruck.bean.TruckDetails;
import com.capgemini.TransportTruck.exception.TransportTruckException;
import com.capgemini.TransportTruck.service.ITruckDeatilsService;
import com.capgemini.TransportTruck.service.TruckDeatilsServiceImpl;
import com.capgemini.TransportTruck.service.Validator;



public class Client {
	
	private static Scanner scanner=new Scanner(System.in);
	private static TruckDetails customer = new TruckDetails();
		private static ITruckDeatilsService orderService = new TruckDeatilsServiceImpl();
		//private static ICustomerService customerService = new CustomerService();
		private static Validator validator = new Validator();

	public static void main(String[] args) throws  TransportTruckException{
		
		while(true){

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  Transport truck Booking System  ");
			System.out.println("_______________________________\n");


			System.out.println("1.Book Trucks");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			Integer option = scanner.nextInt();

			try {

				switch (option) {
				case 1:
					System.out.println("Enter customer Id:");
					String custId = scanner.next();
					if(validator.isValidCustomerId(custId)){
					System.out.println("Types of Trucks Available: ");
					List<TruckDetails> truckDetails=orderService.getTruckDetails();
					Iterator<TruckDetails> iterator= truckDetails.iterator();
					while(iterator.hasNext()){
						System.out.println(iterator.next());
					} 
					//Long truckId= orderService.placeOrder(customerId, totalPrice,quantity);
					System.out.println("Enter the truckId from above available truck details");
					Integer truckId = scanner.nextInt();
					System.out.println("Enter the number of trucks to be booked");
					Integer noOfTrucks = scanner.nextInt();
					Integer trucksAvail = orderService.trucksAvailable(truckId);
					if(noOfTrucks<trucksAvail){
						System.out.println("Enter customer mobile number");
						Long phnnumber = scanner.nextLong();
						if(validator.isValidCustomerMobile(phnnumber)){
							/* Date now = new Date();
						          
						        System.out.print("Enter Date: ");  
						      
						        String ind = scanner.next();;
								DateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");
								Date d = new Date(); 
						try {
						         
						         d=dateformat.parse(ind);
						       
						      
						      }
						      catch(ParseException e) {
						         System.out.println("Unable to parse " + ind);
						      }*/
						 
							//System.out.println("Enter dates in the format dd/MM/yyyy");
							//LocalDate date = LocalDate.now();

							/*SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
							Date date2=null;
							try {
							    //Parsing the String
							    date2 = dateFormat.parse(date);
							} catch (ParseException e) {
							    // TODO Auto-generated catch block
							    e.printStackTrace();
							}
							System.out.println(date2);*/
							
							Long bookingId = orderService.getBookingId(custId, phnnumber, noOfTrucks,truckId);
							System.out.println(" Booking Successful.......\n Your booking id::"+bookingId);
							
							
						}else{
							System.out.println("Enter the valid mobile number");
						}
						
						
					}
					else{
						System.out.println("Sorry!!!!!!!!!"+noOfTrucks+"are not available");
					}
					}
					else{
						System.out.println("Enter the valid Id format ex:A111111");
					}
					break;
					case 2:
					
					System.exit(0);
					break;
				default:
					System.out.println("Enter valid options");
				}
			}catch(NumberFormatException e){
				e.printStackTrace();
			}
	}
	}
	

}
