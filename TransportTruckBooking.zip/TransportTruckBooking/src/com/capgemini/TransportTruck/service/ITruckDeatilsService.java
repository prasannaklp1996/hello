package com.capgemini.TransportTruck.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.capgemini.TransportTruck.bean.TruckDetails;
import com.capgemini.TransportTruck.exception.TransportTruckException;

public interface ITruckDeatilsService {
	public List<TruckDetails> getTruckDetails() throws TransportTruckException ;
	public Integer trucksAvailable(Integer truckId) throws TransportTruckException;
	public Long getBookingId(String custId,
			Long custMobile,Integer noOfTrucks,Integer truckId) throws TransportTruckException;
}
