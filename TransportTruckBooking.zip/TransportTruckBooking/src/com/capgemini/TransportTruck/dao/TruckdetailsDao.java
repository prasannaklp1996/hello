package com.capgemini.TransportTruck.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capgemini.TransportTruck.bean.BookingDetails;
import com.capgemini.TransportTruck.bean.TruckDetails;
import com.capgemini.TransportTruck.exception.TransportTruckException;
import com.capgemini.TransportTruck.utility.DBConnection;





public class TruckdetailsDao implements ITruckdetails {
	//ITruckdetails truckdao = new TruckdetailsDao();
	//BookingDetails bookingdetails = new BookingDetails();
	@Override
	public List<TruckDetails> getTruckDetails() throws TransportTruckException {
int truckCount = 0;
		
		try(Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				){
			ResultSet resultSet = statement.executeQuery(QueryMapper.VIEW_TRUCK_DETAILS);
			List<TruckDetails> trcukList = new ArrayList<>();
			while(resultSet.next()){
				
				truckCount++;
				TruckDetails truck = new TruckDetails();
				populateTruck(truck,resultSet);
				trcukList.add(truck);
				
			}
			if(truckCount!=0){
				
				return trcukList;
			}else{
				return null;
			}
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		
		return null;
	
	}

	private void populateTruck(TruckDetails truck, ResultSet resultSet) throws SQLException {
		truck.setTruckId(resultSet.getInt("truckId"));
		truck.setTruckType(resultSet.getString("truckType"));
		truck.setOrigin(resultSet.getString("origin"));
		truck.setDestination(resultSet.getString("destination"));
		truck.setCharges(resultSet.getDouble("charges"));
		truck.setAvailableNos(resultSet.getInt("availableNos"));
	}
	
	public Integer trucksAvailable(Integer truckId) throws TransportTruckException{
		
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.NUMOF_TRUCK_AVAIL);
				Statement statement =connection.createStatement();
				){
			preparedStatement.setLong(1, truckId);
			ResultSet rs= preparedStatement.executeQuery();
			//preparedStatement.setDouble(2,totalPrice);
			if(rs.next()){
				Integer noOfTrucksAvail = rs.getInt(1);
			
				return noOfTrucksAvail;
			}
		
		
	}catch(SQLException e){
		throw new  TransportTruckException("Trucks are not available");
	}
		return null;
	}
	

	@Override
	public Long getBookingId(String custId, Long custMobile,
			Integer noOfTrucks,Integer truckId)
			throws TransportTruckException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_CUSTOMER_DETAILS);
				Statement statement = connection.createStatement();
				){
			preparedStatement.setString(1, custId);
			preparedStatement.setLong(2,custMobile);
			preparedStatement.setInt(3,truckId);
			preparedStatement.setInt(4,noOfTrucks);
			//System.out.println("in try");
			int n=preparedStatement.executeUpdate();
		

			if(n>0){
				
				ResultSet rs= statement.executeQuery(QueryMapper.BOOKING_ID);
				if(rs.next()){
					Long bookingId = rs.getLong(1);
					
					return bookingId;
				}
			}
			}
	catch( SQLException e){
		e.printStackTrace();
	}

	return null;
	}
	public  Integer updateQuantity(Integer noOfTrucks,Integer truckId)
			throws TransportTruckException {
		try(Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.TRUCK_QUANTITY_UPDATE);

				){
			preparedStatement.setInt(1,noOfTrucks );
			preparedStatement.setInt(2,truckId);

			int n=preparedStatement.executeUpdate();
			if(n>0){
				return n;
			}
		}catch(SQLException e){
			//myMobDAOLogger.error(e.getMessage());
			e.printStackTrace();

		}catch(Exception e){
			//myMobDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return null;

	}

}
