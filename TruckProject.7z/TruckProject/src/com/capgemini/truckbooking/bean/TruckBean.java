package com.capgemini.truckbooking.bean;

public class TruckBean {

	private Integer TruckId;
	private String TruckType;
	private String Origin;
	private String Destination;
	private Float charges;
	private Integer availableNos;
	
	public TruckBean(){
		
	}
	public TruckBean(Integer truckId, String truckType, String origin,
			String destination, Float charges, Integer availableNos) {
		super();
		TruckId = truckId;
		TruckType = truckType;
		Origin = origin;
		Destination = destination;
		this.charges = charges;
		this.availableNos = availableNos;
	}
	
	public Integer getTruckId() {
		return TruckId;
	}
	public void setTruckId(Integer truckId) {
		TruckId = truckId;
	}
	public String getTruckType() {
		return TruckType;
	}
	public void setTruckType(String truckType) {
		TruckType = truckType;
	}
	public String getOrigin() {
		return Origin;
	}
	public void setOrigin(String origin) {
		Origin = origin;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public Float getCharges() {
		return charges;
	}
	public void setCharges(Float charges) {
		this.charges = charges;
	}
	public Integer getAvailableNos() {
		return availableNos;
	}
	public void setAvailableNos(Integer availableNos) {
		this.availableNos = availableNos;
	}
	
	@Override
	public String toString() {
		return "TruckBean [TruckId=" + TruckId + ", TruckType=" + TruckType
				+ ", Origin=" + Origin + ", Destination=" + Destination
				+ ", charges=" + charges + ", availableNos=" + availableNos
				+ "]";
	}
}
