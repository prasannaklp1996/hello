package com.capgemini.truckbooking.dao;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.service.BookingException;

public interface ITruckDao {

	int getBookingId() throws BookingException;
	List<TruckBean> retrieveTruckdetails() throws BookingException;
	int bookTrucks(BookingBean bookingBean)throws BookingException;
	
}
