package com.capgemini.truckbooking.dao;

public class QueryMapper {

    public static final String Book_Truck="insert into bookingdetails values(booking_id_seq.CUURVAL,?,?,?,?,?)";
    public static final String GET_Truck_ID="select truckid from truckdetails where trucktype=?";
    public static final String Retreive_booking_id="select booking_id_seq.NEXTVAL from dual";
    public static final String Get_BOOKING_ID="select bookingid from bookingdetails b,truckdetails t where b.truckid=t.truckid";
    public static final String Get_Truck_Details="select * from truckdetails";
	
}


