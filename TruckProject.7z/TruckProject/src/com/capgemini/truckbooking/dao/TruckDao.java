package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.service.BookingException;
import com.capgemini.truckbooking.utility.DataBaseConnection;

public class TruckDao implements ITruckDao{

	@Override
	public int getBookingId() throws BookingException {
        
		
		return 0;
	}

	@Override
	public List<TruckBean> retrieveTruckdetails() throws BookingException {
		int truckcount=0;
		
		try(   
				Connection conn = DataBaseConnection.getConnection();
				Statement statement=conn.createStatement();
				){
			ResultSet resultSet=statement.executeQuery(QueryMapper.Get_Truck_Details);
			List<TruckBean> trucklist=new ArrayList<>();
			while(resultSet.next()){
				truckcount++;
				TruckBean tdetails=new TruckBean();
				populateTruckDetails(tdetails,resultSet);
				trucklist.add(tdetails);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return null;
	}

	private void populateTruckDetails(TruckBean tdetails, ResultSet resultSet) {

			tdetails.setDestination(resultSet.getString("Destination"));
			tdetails.setOrigin(resultSet.getString("Origin"));
			tdetails.setCharges(resultSet.getFloat("charges"));
			tdetails.setQuantity(resultSet.getInt("quantity"));
		
		
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		return 0;
	}

}
