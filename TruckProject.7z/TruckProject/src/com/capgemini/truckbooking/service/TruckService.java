package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;

public class TruckService implements ITruckService{

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {

		
		return null;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {

		
		return 0;
	}

}
