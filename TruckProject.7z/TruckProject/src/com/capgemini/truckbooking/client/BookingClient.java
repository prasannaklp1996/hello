package com.capgemini.truckbooking.client;

public class BookingClient {

	public static void main(String[] args) {

		System.out.println("Booking Operations");
		System.out.println("1.Book Details");
		System.out.println("2.exit");
		
		
	}

}
